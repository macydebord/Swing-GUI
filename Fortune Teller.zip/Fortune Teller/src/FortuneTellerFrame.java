import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.util.Random;

public class FortuneTellerFrame extends JFrame
{
    private final JLabel titleLabel;
    private final JTextArea fortuneArea;
    private final JButton fortuneButton;
    private final JButton quitButton;

    private final ArrayList<String> fortunes;
    private int previousIndex = -1;

    public FortuneTellerFrame()
    {
        super("Fortune Teller");
        //jframe
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(600, 600);
        setResizable(false);
        setLocationRelativeTo(null);

        //fortunes
        fortunes = new ArrayList<>();
        fortunes.add("Fortune 1: To truly find yourself you should play hide and seek alone");
        fortunes.add("Fortune 2: Come back later... I am sleeping");
        fortunes.add("Fortune 3: It could be better, but it's good enough");
        fortunes.add("Fortune 4: It would be best to maintain a low profile for now");
        fortunes.add("Fortune 5: Error 404: Fortune Not Found");
        fortunes.add("Fortune 6: Ask not what your fortune cookie can do for you but what you can do for your fortune cookie");
        fortunes.add("Fortune 7: I see money in your future... it's not yours though");
        fortunes.add("Fortune 8: Ignore previous fortune");
        fortunes.add("Fortune 9: Ask your mom");
        fortunes.add("Fortune 10: In two days, tomorrow will be yesterday");
        fortunes.add("Fortune 11: *empty*");
        fortunes.add("Fortune 12: How much deeper would the ocean be without sponges?");

        // top panel
        JPanel topPanel = new JPanel();
        topPanel.setLayout(new BoxLayout(topPanel, BoxLayout.Y_AXIS));
        ImageIcon fortuneTellerIcon = new ImageIcon("src/images.jpg");
        JLabel iconLabel = new JLabel(fortuneTellerIcon);
        iconLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        titleLabel = new JLabel("Fortune Teller");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 36));
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        topPanel.add(titleLabel);
        topPanel.add(iconLabel);

        // middle panel
        JPanel middlePanel = new JPanel(new BorderLayout());
        fortuneArea = new JTextArea();
        fortuneArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(fortuneArea);
        middlePanel.add(scrollPane, BorderLayout.CENTER);

        // bottom panel
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        fortuneButton = new JButton("Read My Fortune!");
        fortuneButton.addActionListener((ActionEvent e) -> showFortune());
        quitButton = new JButton("Quit");
        quitButton.addActionListener((ActionEvent e) -> System.exit(0));
        bottomPanel.add(fortuneButton);
        bottomPanel.add(quitButton);

        add(topPanel, BorderLayout.NORTH);
        add(middlePanel, BorderLayout.CENTER);
        add(bottomPanel, BorderLayout.SOUTH);

        pack();
        centerFrame();
    }

    private void showFortune()
    {
        int index = new Random().nextInt(fortunes.size());
        while (index == previousIndex)
        {
            index = new Random().nextInt(fortunes.size());
        }
        previousIndex = index;
        String fortune = fortunes.get(index);
        fortuneArea.append(fortune + "\n");
    }

    private void centerFrame()
    {
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        int width = screenSize.width * 3 / 4;
        int height = screenSize.height * 3 / 4;
        setLocation((screenSize.width - width) / 2, (screenSize.height - height) / 2);
        setSize(width, height);
    }
}
